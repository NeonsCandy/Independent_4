def hello(name="World"):
    """Возвращает приветствие."""
    return f"Hello, {name}!"
